<?php
Class Percobaan extends CI_Controller {
    public function Index()
    {
        echo 'Hi PHP Indonesia';
        echo '<br />';
        echo 'ini adalah fungsi yang dipanggil secara default';
    }

    public function halo()
    {
        echo 'ini adalah method halo';
        echo '<>br />';
        echo 'fungsi ini merupakan fungsi kedua dalam class percobaan';]
    }
    public function tampil()
    {
        echo ''
    }
}