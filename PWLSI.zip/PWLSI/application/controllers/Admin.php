<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // pastikan model dimuat
        $this->load->model('User_model');
        $this->load->library('session');

        // validasi admin login
        if ($this->session->userdata('role') != 'admin') {
            redirect('auth/login');
        }
    }

    public function dashboard_admin()
    {
        $data['jumlah_guru'] = $this->User_model->count_guru();
        $data['jumlah_murid'] = $this->User_model->count_murid();
        $data['guru'] = $this->User_model->get_all_guru();
        $data['anak'] = $this->User_model->get_all_anak();
        $data['transaksi'] = $this->User_model->get_all_transaksi();

        $this->load->view('admin/dashboard_admin', $data);
    }

    public function edit_anak($id_anak)
    {
        $data['anak'] = $this->User_model->get_anak_by_id($id_anak);

        if (empty($data['anak'])) {
            show_404();
        }

        if ($this->input->post()) {
            $update = $this->User_model->update_anak($id_anak, $this->input->post());
            if ($update) {
                $this->session->set_flashdata('message', 'Data anak berhasil diperbarui.');
            }
            redirect('admin/dashboard');
        }

        $this->load->view('admin/edit_anak', $data); // Buatkan view edit_anak nanti
    }

    public function hapus_anak($id_anak)
    {
        $this->User_model->delete_anak($id_anak);
        $this->session->set_flashdata('message', 'Data anak berhasil dihapus.');
        redirect('admin/dashboard');
    }

    public function set_lunas($id_transaksi)
    {
        $this->User_model->update_status_lunas($id_transaksi);
        $this->session->set_flashdata('message', 'Status pembayaran berhasil diubah menjadi Lunas.');
        redirect('admin/dashboard');
    }
}
