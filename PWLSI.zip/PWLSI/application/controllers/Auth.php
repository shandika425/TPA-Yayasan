<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('session');
    }

    public function login()
    {
        $this->load->view('auth/login');
    }

    public function do_login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        // Memanggil metode get_by_email()
        $user = $this->User_model->get_by_email($email);

        // Validasi pengguna dan password
        if ($user && password_verify($password, $user->password)) {
            // Set session
            $this->session->set_userdata([
                'id_user' => $user->id_user,
                'email'   => $user->email,
                'role'    => $user->role
            ]);

            // Redirect berdasarkan peran pengguna
            if ($user->role == 'admin') {
                redirect(site_url('admin/dashboard_admin'));
            } else {
                redirect(site_url('user/cek_formulir'));
            }
        } else {
            // Jika login gagal
            $this->session->set_flashdata('error', 'Email atau Password salah');
            redirect('auth/login');
        }
    }

    public function logout()
    {
        // Hancurkan sesi dan redirect ke halaman login
        $this->session->sess_destroy();
        redirect('auth/login');
    }
    public function hash_password_admin()
    {
        $password_baru = password_hash("kelompok11", PASSWORD_BCRYPT);
        echo $password_baru;
    }

}
