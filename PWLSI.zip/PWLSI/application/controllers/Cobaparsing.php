<?php
defined('BASEPATH') OR exit ('No direct script access allowed');
class Cobaparsing extends CI_Controller {

    function __construct(){
    parent::__construct();
    }
    public function index(){
    echo "ini method index pada controller Coba Parsing | cara membuat controller pada codeigniter ";
}
public function halo(){
$data = array(
'judul' => "Cara Membuat View Pada CodeIgniter",
'tutorial' => "CodeIgniter"
);
$this->load->view('v_cobaparsing', $data);
}
}