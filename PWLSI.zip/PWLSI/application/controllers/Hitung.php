<?
/*
    Nama : Faris H
    NPM  : 2023320008
    Version : 1.0 
    email : FarisH@gmail.com
*/
defined('BASEPATH') OR exit('No direct script access allowed');

class Hitung extends CI_Controller {
    function __construct() {
    parent:: __construct();
     $this->load->helper(array('url','form'));
    }

    public function index()// fungsi default dijalankan
    {
        $this->load->view('menu_hitung'); //menampilkan menu hitung pada view
    }

    function Perkalian() // Fungsi untuk melakukan perkalian antar 2 variabel
    {
        $data['d1']=(int) $this->input->post('d1', true);
        $data['d2']=(int) $this->input->post('d2', true);
        $data['hasil']=$data['d1']*$data['d2'];
        $this->load->view('perkalian',$data);
    }

    function Pembagian() // Fungsi untuk melakukan perkalian antar 2 variabel
    {
        $data['d1']=(int) $this->input->post('d1', true);
        $data['d2']=(int) $this->input->post('d2', true);
         if($data['d2']>0)
            $data['hasil']=$data['d1']/$data['d2']
         else
            $data['hasil']='error, d2 tidak boleh 0';
            $this->load->view('pembagian',$data);
    }
}