<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->model('Transaksi_model'); // Model untuk transaksi
        $this->load->library('session');

        $allowed = ['auth', 'logout']; // tambahkan pengecualian
        $current_class = $this->router->fetch_class();
        $current_method = $this->router->fetch_method();

        if (!in_array($current_class, $allowed) && !$this->session->userdata('id_user')) {
            redirect('auth/login');
        }
    }

    public function cek_formulir() {
        $id_user = $this->session->userdata('id_user');
        $sudah_isi = $this->User_model->cek_formulir_sudah_isi($id_user);

        if ($sudah_isi) {
            redirect('user/dashboard');
        } else {
            redirect('user/formulir_tpa');
        }
    }

    public function formulir_tpa() {
        $this->load->view('templates/header');
        $this->load->view('pendaftaran/formulir_tpa');
        $this->load->view('templates/footer');
    }

    public function simpan_formulir() {
        $id_user = $this->session->userdata('id_user');

        // Data untuk tabel data_anak
        $data_anak = [
            'id_user'         => $id_user,
            'nama_anak'       => $this->input->post('nama_anak'),
            'tingkat_sekolah' => $this->input->post('tingkat_sekolah'),
            'jenis_kelamin'   => $this->input->post('jenis_kelamin'),
            'bisa_membaca'    => $this->input->post('bisa_membaca'),
            'pengalaman_tpa'  => $this->input->post('pengalaman_tpa'),
            'hafalan'         => $this->input->post('hafalan'),
        ];

        // Simpan data ke tabel data_anak
        $this->db->insert('data_anak', $data_anak);
        $id_anak = $this->db->insert_id(); // Ambil ID anak yang baru saja disimpan

        // Tambahkan data transaksi terkait
        $this->simpan_transaksi($id_user, $id_anak);

        redirect('user/dashboard'); // Arahkan kembali ke dashboard
    }

    private function simpan_transaksi($id_user, $id_anak) {
        // Transaksi 1 - Infaq Masjid
        $this->Transaksi_model->tambah_transaksi([
            'id_user' => $id_user,
            'id_anak' => $id_anak,
            'keterangan' => 'Infaq Masjid',
            'tgl_bayar' => null,
            'jumlah_bayar' => 150000,
            'status' => 'Pending'
        ]);

        // Transaksi 2-7 - SPP Bulan Januari - Juni
        $bulan = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'];
        foreach ($bulan as $b) {
            $this->Transaksi_model->tambah_transaksi([
                'id_user' => $id_user,
                'id_anak' => $id_anak,
                'keterangan' => 'SPP Bulan ' . $b,
                'tgl_bayar' => null,
                'jumlah_bayar' => 30000,
                'status' => 'Pending'
            ]);
        }
    }

    public function dashboard() {
        $id_user = $this->session->userdata('id_user');
        $data['transaksi'] = $this->Transaksi_model->get_by_user($id_user);

        $this->load->view('templates/header');
        $this->load->view('user/dashboard_user', $data);
        $this->load->view('templates/footer');
    }

    public function bayar($id_transaksi) {
        // Update status transaksi menjadi "Lunas"
        $this->Transaksi_model->update_status($id_transaksi, 'Lunas');

        // Redirect kembali ke dashboard dengan pesan sukses
        $this->session->set_flashdata('message', 'Pembayaran berhasil!');
        redirect('user/dashboard');
    }
}
