<?php
class Percobaan extends CI_Controller{
    public function index()
    {
        echo 'Hai PHP Indonesia';
        echo '<br/>';
        echo 'Ini adalah tugas fungsi yang dipanggil secara default';
    }

    public function halo() 
    {
        echo 'ini adalah method halo()';
        echo '<br/>';
        echo 'fungsi ini merupakan fungsi kedua dalam class pemrograman';
    }

    public function tampil()
    {
        echo $this->halo();
    }
}

?>