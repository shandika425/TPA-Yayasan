<?php

class Guru_model extends CI_Model {
    public function hitung_guru() {
        return $this->db->count_all('guru');
    }

    public function get_all() {
        return $this->db->get('guru')->result_array();
    }
}
