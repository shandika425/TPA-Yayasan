<?php
defined('BASEPATH') OR exit ('NO direct script access allowed');

class Mkuker extends CI_Model
{
    public function get_product()
    {
        $this->db->select('*');
        $this->db->from('dbproduct');
        return $this->db->get();
    }
}