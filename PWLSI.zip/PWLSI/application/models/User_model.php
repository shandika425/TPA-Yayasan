<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    // === Untuk Data Anak ===
    public function get_all_anak()
    {
        // Menambahkan join dengan tabel 'users' untuk mengambil 'nama_wali'
        $this->db->select('data_anak.*, users.nama_wali');
        $this->db->from('data_anak');
        $this->db->join('users', 'users.id_user = data_anak.id_user'); // Pastikan relasi ini benar
        return $this->db->get()->result_array(); // Mengembalikan data dalam bentuk array
    }

    public function get_anak_by_id($id_anak)
    {
        return $this->db->get_where('data_anak', ['id_anak' => $id_anak])->row_array();
    }

    public function update_anak($id_anak, $data)
    {
        return $this->db->update('data_anak', $data, ['id_anak' => $id_anak]);
    }

    public function delete_anak($id_anak)
    {
        return $this->db->delete('data_anak', ['id_anak' => $id_anak]);
    }

    // === Untuk Transaksi Pembayaran ===
    public function get_all_transaksi()
    {
        $this->db->select('transaksi.*, data_anak.nama_anak');
        $this->db->from('transaksi');
        $this->db->join('data_anak', 'transaksi.id_anak = data_anak.id_anak');
        return $this->db->get()->result_array();
    }

    public function update_status_lunas($id_transaksi)
    {
        $data = [
            'status' => 'Lunas',
            'tgl_bayar' => date('Y-m-d')
        ];
        return $this->db->update('transaksi', $data, ['id_transaksi' => $id_transaksi]);
    }

    // === Hitungan Guru & Murid ===
    public function count_guru()
    {
        return $this->db->count_all('guru');
    }

    public function count_murid()
    {
        return $this->db->count_all('data_anak');
    }

    public function get_all_guru()
    {
        return $this->db->get('guru')->result_array();
    }

    // === Metode Tambahan: get_by_email() ===
    public function get_by_email($email)
    {
        $this->db->where('email', $email);
        return $this->db->get('users')->row(); // Pastikan tabel 'users' sesuai database Anda
    }

    public function cek_formulir_sudah_isi($id_user)
    {
        $this->db->where('id_user', $id_user);
        $query = $this->db->get('data_anak');
        return $query->num_rows() > 0;
    }
    public function simpan_formulir_tpa($data)
    {
        return $this->db->insert('data_anak', $data);
    }


}
