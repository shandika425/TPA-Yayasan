<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
    <style>
        /* === Sidebar Styling === */
        .sidebar {
            width: 240px;
            background: linear-gradient(135deg,rgb(5, 0, 96),rgb(0, 0, 0));
            color: white;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 20px;
            font-size: 20px;
            font-weight: bold;
            background-color:rgb(5, 0, 61);
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .profile-section {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .profile-section img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            border: 2px solid white;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            font-size: 16px;
        }

        .profile-info small {
            font-size: 13px;
            color: #ccc;
        }

        .nav-menu {
            list-style: none;
            padding: 20px;
            margin: 0;
            flex-grow: 1;
        }

        .nav-menu li {
            margin-bottom: 12px;
        }

        .nav-menu a {
            display: block;
            background-color:rgb(5, 0, 61);
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }

        .nav-menu a:hover {
            background-color:rgb(80, 123, 233);
        }

        .nav-menu a.active {
            background-color:rgb(19, 86, 255);
            font-weight: bold;
        }

        /* === Content Styling === */
        .content {
            margin-left: 260px;
            padding: 30px;

            
        }

        .box {
            background-color:rgb(5, 0, 61);
            color:white;
            font-size: 20px;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 2px 6px rgba(70, 68, 68, 0.1);
        }

        table {
            background-color: white;
        }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="sidebar-header">
    <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo" width="34" class="mr-1"> Yayasan Al Fatah
    </div>

    <div class="profile-section">
        <img src="<?= base_url('assets/img/av1.jpg') ?>" alt="Foto Profil">
        <div class="profile-info">
            <strong>Nofal Asyhari, S.T</strong>
            <small>Admin</small>
        </div>
    </div>

    <ul class="nav-menu">
        <li><a href="#" class="active">Dashboard</a></li>
        <li><a href="#">Siswa</a></li>
        <li><a href="#">Kegiatan</a></li>
        <li><a href="#">Administrasi</a></li>
        <li><a href="<?= base_url('auth/login') ?>">Logout</a></li>
    </ul>
</div>

<div class="content">
    <h2><b>Dashboard Ketua Yayasan</b></h2>
<br>
    <div class="row">
        <div class="col-md-3">
            <div class="box">
                <p>Jumlah Guru</p>
                <h4><?= $jumlah_guru ?></h4>
            </div>
        </div>
        <div class="col-md-3">
            <div class="box">
                <p>Jumlah Murid</p>
                <h4><?= $jumlah_murid ?></h4>
            </div>
        </div>
    </div>

    <!-- ... potongan sebelumnya tetap ... -->
    <div class="mt-4">
        <h5>Data Guru</h5>
        <table class="table table-bordered table-striped" id="guruTable">
            <thead class="bg-primary text-white">
                <tr>
                    <th>Nama</th>
                    <th>NIP</th>
                    <th>Mapel</th>
                    <th>Alamat</th>
                    <th>No.Tlp</th>
                    <th>Status Aktif</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($guru as $g): ?>
                    <tr>
                        <td><?= $g['nama_guru'] ?></td>
                        <td><?= $g['nip'] ?></td>
                        <td><?= $g['mapel'] ?></td>
                        <td><?= $g['alamat'] ?></td>
                        <td><?= $g['no_telp'] ?></td>
                        <td><?= $g['status'] ?></td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>

    <!-- ========== Tambahan Data Anak ========== -->
    <div class="mt-5">
        <h5>Data Anak</h5>
        <table class="table table-bordered table-striped" id="anakTable">
            <thead class="bg-primary text-white">
                <tr>
                    <th>Nama Wali</th>
                    <th>Nama Anak</th>
                    <th>Tingkat Sekolah</th>
                    <th>Jenis Kelamin</th>
                    <th>Status Membaca</th>
                    <th>Pengalaman TPA</th>
                    <th>Hafalan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($anak as $a): ?>
                    <tr>
                        <td><?= $a['nama_wali'] ?></td>
                        <td><?= $a['nama_anak'] ?></td>
                        <td><?= $a['tingkat_sekolah'] ?></td>
                        <td><?= $a['jenis_kelamin'] ?></td>
                        <td><?= $a['bisa_membaca'] ?></td>
                        <td><?= $a['pengalaman_tpa'] ?></td>
                        <td><?= $a['hafalan'] ?></td>
                        <td>
                            <a href="<?= base_url('admin/edit_anak/' . $a['id_anak']) ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="<?= base_url('admin/hapus_anak/' . $a['id_anak']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- ========== Tambahan Data Pembayaran ========== -->
    <div class="mt-5">
        <h5>Data Pembayaran</h5>
        <table class="table table-bordered table-striped" id="pembayaranTable">
            <thead class="bg-primary text-white">
                <tr>
                    <th>ID Transaksi</th>
                    <th>Nama Anak</th>
                    <th>Keterangan</th>
                    <th>Tanggal Bayar</th>
                    <th>Jumlah</th>
                    <th>Status</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transaksi as $row): ?>
                    <tr>
                        <td><?= $row['id_transaksi'] ?></td>
                        <td><?= $row['nama_anak'] ?></td>
                        <td><?= $row['keterangan'] ?></td>
                        <td><?= $row['tgl_bayar'] ? date('d-m-Y', strtotime($row['tgl_bayar'])) : '-' ?></td>
                        <td>Rp <?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></td>
                        <td>
                            <span class="badge badge-<?= $row['status'] == 'Lunas' ? 'success' : 'warning' ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($row['status'] == 'Pending') : ?>
                                <a href="<?= base_url('admin/set_lunas/' . $row['id_transaksi']) ?>" class="btn btn-sm btn-success">Tandai Lunas</a>
                            <?php else: ?>
                                <button class="btn btn-sm btn-secondary" disabled>Lunas</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#guruTable').DataTable({ "pageLength": 5 });
        $('#anakTable').DataTable({ "pageLength": 5 });
        $('#pembayaranTable').DataTable({ "pageLength": 5 });
    });
</script>

</body>
</html>

