<?php $this->load->view('templates/header'); ?>

<main class="foto-kegiatan-bg text-white text-center d-flex align-items-center justify-content-center" style="min-height: 100vh; position: relative;">
    <div class="overlay position-absolute w-100 h-100"></div>
    <div class="content position-relative z-2 px-3">
        <h2 class="mb-1">SELAMAT DATANG</h2>
        <h6>Di Website Resmi Kami</h6>
        <h5 class="mt-4">MASJID BAITUL MUTTAQIEN</h5>
        <p class="lead">Merupakan tempat ibadah, kegiatan sosial, dan keagamaan yang aktif dengan berbagai aktivitas yang melibatkan masyarakat sekitar.</p>
        <p>Berbagai kegiatan rutin seperti pengajian, bakti sosial, hingga pembelajaran anak-anak dilakukan setiap hari.</p>
        <h4 class="mt-5">Masjid Baitul Muttaqien</h4>
        <p class="font-weight-bold">Masjid Baitul Muttaqien</p>
    </div>
</main>



<?php $this->load->view('templates/footer'); ?>
