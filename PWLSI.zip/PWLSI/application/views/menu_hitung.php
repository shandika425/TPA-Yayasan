<h2> Menu Aritmatika</h2>
<ul>
    <li><?php echo anchor('hitung/penjumlahan', 'Penjumlahan');?>
    <li><?php echo anchor('hitung/perkalian', 'Perkalian');?>
    <li><?php echo anchor('hitung/pembagian', 'Pembagian');?>
    <li><?php echo anchor('hitung/pengurangan', 'Pengurangan');?>
</ul>