<div class="container mt-5">
    <h3>Formulir Pendaftaran TPA Anak</h3>
    <form action="<?= base_url('pendaftaran/simpan_formulir') ?>" method="post">
        <div class="form-group">
            <label>Nama Anak</label>
            <input type="text" name="nama_anak" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Tingkat Sekolah</label>
            <input type="text" name="tingkat_sekolah" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Jenis Kelamin</label>
            <select name="jenis_kelamin" class="form-control" required>
                <option value="">Pilih Jenis Kelamin</option>
                <option value="Laki-laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
        </div>
        <div class="form-group">
            <label>Bisa Membaca Al-Qur'an?</label>
            <select name="bisa_membaca" class="form-control" required>
                <option value="">Pilih</option>
                <option value="Ya">Ya</option>
                <option value="Belum">Belum</option>
            </select>
        </div>
        <div class="form-group">
            <label>Pengalaman di TPA lain?</label>
            <select name="pengalaman_tpa" class="form-control" required>
                <option value="">Pilih</option>
                <option value="Ya">Ya</option>
                <option value="Tidak">Tidak</option>
            </select>
        </div>
        <div class="form-group">
            <label>Hafalan Surah Pendek yang Dikuasai</label>
            <textarea name="hafalan" class="form-control" rows="3" required></textarea>
        </div>

        <button type="submit" class="btn btn-success mt-3">Simpan dan Lanjut ke Dashboard</button>
    </form>
</div>
