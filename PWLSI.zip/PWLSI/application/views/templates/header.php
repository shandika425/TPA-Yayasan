<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil Masjid</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">

    <style>
        .navbar-nav .nav-link.active {
            font-weight: bold;
            text-decoration: underline;
        }

        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
        }

        main {
            flex: 1;
        }

        .foto-kegiatan-bg {
            background: url('<?= base_url("assets/img/Masjid.jpg") ?>') no-repeat center center;
            background-size: cover;
            position: relative;
        }

        .foto-kegiatan-bg .overlay {
            background-color: rgba(0, 0, 0, 0.5);
            position: absolute;
            top: 0;
            left: 0;
            z-index: 1;
            width: 100%;
            height: 100%;
        }

        .foto-kegiatan-bg .content {
            z-index: 2;
            max-width: 800px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="<?= base_url() ?>">
            <img src="<?= base_url('assets/img/logo.png') ?>" alt="Logo" width="55" class="mr-2">
            <span class="font-weight-bold">Yayasan Harapan Mulya</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link <?= ($this->uri->segment(1) == '') ? 'active' : '' ?>" href="<?= base_url() ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Artikel</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Visi-Misi</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Informasi</a></li>
                <li class="nav-item"><a class="nav-link <?= ($this->uri->segment(1) == 'pendaftaran') ? 'active' : '' ?>" href="<?= base_url('pendaftaran') ?>">Pendaftaran Online</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Kontak</a></li>
                <li class="nav-item"><a class="nav-link" href="<?= base_url('auth/login') ?>">Masuk</a></li>
            </ul>
        </div>
    </div>
</nav>
