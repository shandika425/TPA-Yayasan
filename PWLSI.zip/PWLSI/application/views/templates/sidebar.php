<a href="<?php echo site_url('auth/logout'); ?>" class="nav-link">
    <i class="fas fa-sign-out-alt"></i>
    <span>Logout</span>
</a>
