<div class="container mt-5">
    <h3>Selamat Datang di Dashboard User</h3>
    <p>Silakan lihat informasi pendaftaran Anda atau fitur lainnya di sini.</p>

    <hr>

    <?php if (!empty($this->session->flashdata('message'))) : ?>
        <div class="alert alert-success">
            <?= $this->session->flashdata('message') ?>
        </div>
    <?php endif; ?>

    <h4>Data Administrasi Pembayaran</h4>
    <div class="table-responsive">
        <table class="table table-bordered table-striped mt-3">
            <thead class="thead-dark">
                <tr>
                    <th>ID Transaksi</th>
                    <th>Keterangan</th>
                    <th>Nama Anak</th>
                    <th>Tanggal Bayar</th>
                    <th>Jumlah Bayar</th>
                    <th>Status</th>
                    <th>Opsi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($transaksi)) : ?>
                    <?php foreach ($transaksi as $row) : ?>
                        <tr>
                            <td><?= $row['id_transaksi'] ?></td>
                            <td><?= $row['keterangan'] ?></td>
                            <td><?= $row['nama_anak'] ?></td>
                            <td><?= $row['tgl_bayar'] ? date('d-m-Y', strtotime($row['tgl_bayar'])) : '-' ?></td>
                            <td>Rp <?= number_format($row['jumlah_bayar'], 0, ',', '.') ?></td>
                            <td>
                                <span class="badge badge-<?= $row['status'] == 'Lunas' ? 'success' : 'warning' ?>">
                                    <?= ucfirst($row['status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row['status'] == 'Pending') : ?>
                                    <a href="<?= base_url('user/bayar/' . $row['id_transaksi']) ?>" class="btn btn-sm btn-primary">Bayar</a>
                                <?php else : ?>
                                    <a href="#" class="btn btn-sm btn-secondary">Cetak</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="7" class="text-center text-danger">Belum ada data pembayaran.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <a href="<?= base_url('auth/logout') ?>" class="btn btn-danger mt-4">Logout</a>
</div>
