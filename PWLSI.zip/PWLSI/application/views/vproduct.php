<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <div class="card mb-4 mx-3 mt-3"></div>
            <div class="card-header">
                <a href="<?php echo base_url('dashboard/add_product') ?>" class="btn btn-primary">Tambah Produk</a>
        </div>
        <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Deskripsi</th>
                        <th>Gambar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach($dbproduk as $p){
                    ?>
                    <tr>
                        <th scope="row"><?php echo $no++ ?></th>
                        <td><?php echo $p->nama_produk?></td>
                        <td><?php echo $p->harga?></td>
                        <td><?php echo $p->deskripsi?></td>
                        <td><img src="<?php echo base_url('upload/'.$p->gambar) ?>" width="100" height="100"></td>
                        <td>
                            <a href="<?php echo base_url('dashboard/edit_product/'.$p->id_product) ?>" class="btn btn-success">Edit</a>
                            <a href="<?php echo base_url('dashboard/delete_product/'.$p->id_product) ?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        </div>
    </main>