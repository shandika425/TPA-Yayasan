$(document).ready(function () {
    $('#menuPendaftaran').on('click', function (e) {
        e.preventDefault();
        $('#kontenSyarat').fadeIn();
        $('#formDaftar, #formLogin').hide();
    });

    $('#btnDaftar').on('click', function () {
        $('#formDaftar').fadeIn();
        $('#kontenSyarat, #formLogin').hide();
    });

    $('#goToLogin').on('click', function (e) {
        e.preventDefault();
        $('#formLogin').fadeIn();
        $('#kontenSyarat, #formDaftar').hide();
    });

    $('#menuHome').on('click', function () {
        $('#kontenSyarat, #formDaftar, #formLogin').hide();
    });
});
